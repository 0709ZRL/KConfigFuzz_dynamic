//! Interesting value pool extracted from the progs in the corpus.

/// TODO
pub struct ValuePool;
