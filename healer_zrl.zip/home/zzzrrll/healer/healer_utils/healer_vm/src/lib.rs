pub mod qemu;
pub mod ssh;

pub type HashMap<K, V> = ahash::AHashMap<K, V>;
pub type HashSet<K> = ahash::AHashSet<K>;
