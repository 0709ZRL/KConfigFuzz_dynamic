pub mod exec;
pub mod report;
pub mod repro;
pub mod sys;

type HashMap<K, V> = ahash::AHashMap<K, V>;
type HashSet<K> = ahash::AHashSet<K>;
